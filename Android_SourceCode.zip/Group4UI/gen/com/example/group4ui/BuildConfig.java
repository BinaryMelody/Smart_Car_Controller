/** Automatically generated file. DO NOT MODIFY */
package com.example.group4ui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}