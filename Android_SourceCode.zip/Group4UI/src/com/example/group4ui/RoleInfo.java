package com.example.group4ui;

public class RoleInfo {
	private String mStrName;
	private String mStrUserID;

	public void setName(String strName) {
		mStrName = strName;
	}

	public String getName() {
		return mStrName;
	}

	public void setUserID(String strUserID) {
		mStrUserID = strUserID;
	}

	public String getUserID() {
		return mStrUserID;
	}

}
